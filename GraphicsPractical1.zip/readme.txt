Gert-Jan van Ginkel		5490723
Mehul Mistry			4255704
Norico Groeneveld		4301358

We didn't want to hurt your eyes with our simple implementation of terrain coloring, so we commented it out in Terrain.cs